"Growling Lion" by Andreas Heiberg is a Growl Style based on the Safari 5.1 downloads window. Its based on Christopher Lobays "Mono".
(For more information go to: http:// www.andreas-heiberg.com/Blog/ 2011/07/23/growl-growlinglion-lion-inspired- growl-theme/)

I made a view adaptations to my liking and I may add some more effects later too. So far I ...
- increased fontsize a bit
- added high and emergency priority styles 
- fixed some spacing
Thanks to Andreas and Christopher for this.
Enjoy, Christian

Changelog:
1.1 2011-08-25 
- added a bit of space to the right 
- changed icon/picture size from 34px to 40px
- some more related spacing stuff related to the icon change